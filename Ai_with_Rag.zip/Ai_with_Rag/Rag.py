

from langchain_text_splitters import CharacterTextSplitter
import pdfplumber

pdf_path = r"Ai_with_Rag\6th_Social_Science_Term_I_EM - www.tntextbooks.in.pdf"

all_text = []

with pdfplumber.open(pdf_path) as pdf:
    for page_num, page in enumerate(pdf.pages[:15], start=1):
        text = page.extract_text() or ""
        
        all_text.append(f"\n--- Page {page_num} ---\n")
        all_text.append(text)

full_text = "\n".join(all_text)

print(full_text[:500])


# with open(pdf_path,"r",encoding="utf-8") as f:
#     full_text = f.read()
    
#     print(full_text[:500])


text_splitter = CharacterTextSplitter(
    chunk_size=800,
    chunk_overlap=200
)
text=text_splitter.split_text(full_text)
# print(text[:10])

for i,char in enumerate(text):
    if i ==5:
        break
    print(char,'char----------')
    















